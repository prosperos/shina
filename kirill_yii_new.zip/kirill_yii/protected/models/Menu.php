<?php

/**
 * This is the model class for table "menu".
 *
 * The followings are the available columns in table 'menu':
 * @property string $id
 * @property string $real_title
 * @property string $trans_title
 */
class Menu extends IWLActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'menu';
	}

	/**
	 * @return array validation rules for model attributes.
	 */


	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Menu the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}



// Создание своих методов

	public function selectGallaryName()
    {
      $connection=Yii::app()->db;
      $sql = "SELECT * FROM  menu";
      $sqlCommand = $connection->CreateCommand($sql);
      
        $rows = $sqlCommand->queryAll();
        return $rows;                
    }





}
