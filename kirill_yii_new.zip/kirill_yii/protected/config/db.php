<?php

return array(
    'components' => array(
        'db'=>array(
            'connectionString' => 'mysql:host=localhost;dbname=medapp',
            'emulatePrepare' => true,
            'username' => 'root',
            'password' => '',            
            'charset' => 'utf8',
        )
    )
);

?>
