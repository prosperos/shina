<?php

class IWLActiveRecord extends CActiveRecord
{

}

?>
