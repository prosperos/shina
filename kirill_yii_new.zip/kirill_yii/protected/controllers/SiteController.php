<?php


class SiteController extends Controller
{
    public $defaultAction = "index";
    public $currentCatalogue = null;
    


    public function actionIndex()
    {
        echo "Hello";   
	
    $mytest = Menu::model()->selectGallaryName();
	//$product_combo = CatalogTree::model()->allCombo();   
   //$mytest = MyModel::model()->selectGallaryName();

	var_dump($mytest);
     
   /*     $check_for_gallery = array();
        $product_combo = CatalogTree::model()->allCombo(); 
        $dataGallary = Article::model()->selectImagesSlider(1);                
        $this->currentCatalogue = CatalogTree::model()->with(array('products', 'products.parameters', 'parent', 'descendants'))->find('parent.chpu = :catalogue AND t.chpu = :category', array(':catalogue' => 'katalog', ':category' => 'uslugi'));  
        $this->render('index', array('combo'=>$product_combo,'gallary'=>$dataGallary,'catalogue' => $this->currentCatalogue));*/
    }

      
   
          public function selectGallaryName()
    {
      $connection=Yii::app()->db;
      $sql = "SELECT title 
        FROM  gallery_category";
      $sqlCommand = $connection->CreateCommand($sql);
      
        $rows = $sqlCommand->queryAll();
        return $rows;                
    }



public function actionTest(){
echo 'TestPage';
    $this->render('testpage');
}



}

?>
