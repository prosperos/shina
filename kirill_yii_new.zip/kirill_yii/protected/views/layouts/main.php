

<!DOCTYPE html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fotolab</title>
    <link href="<?php echo  Yii::app()->request->getBaseUrl(true); ?>/img/favicon.ico" rel="shortcut icon" type="image/x-icon" />
    <!-- Bootstrap -->
    <link href="<?php echo  Yii::app()->request->getBaseUrl(true); ?>/css/bootstrap.min.css" rel="stylesheet">

      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link href="<?php echo  Yii::app()->request->getBaseUrl(true); ?>/css/css.css" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  </head>
  <body>



                      <?php



                      echo $content;

?>













  </body>
</html>


